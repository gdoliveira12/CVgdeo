const submitcontinuaruno = document.querySelector("#submitcontinuaruno");
const submitcontinuardos = document.querySelector("#submitcontinuardos");
const submitcontinuartres = document.querySelector("#submitcontinuartres");
const segnum = document.querySelector("#segnum");






const segundaparte = () => {
    primform.classList.toggle("show");
    segform.classList.toggle("show");
    const name = document.getElementById("nombre").value;
    const textosgdo = document.getElementById("sgdotexto").innerHTML = `Hola  ${name} El juego consiste en lo siguiente: tendrás que indicarnos un número del 1 al 10 y después otro del 30 al 40. Entonces, la máquina seleccionará, de manera aleatoria, otro dentro del rango comprendido entre las dos cifras que has designado. Tendrás 5 intentos para adivinarlo.`;
};

const nums = () => {
    pnumprimero.classList.toggle("show");
    pnumsegundo.classList.toggle("show");
    primnum.classList.toggle("show");
    segnum.classList.toggle("show");
    submitcontinuardos.classList.toggle("show");
    const primnumvalue = document.getElementById("primnum").value;
    const confprimnum = document.getElementById("confprimnum").innerHTML = `Tu primer número es ${primnumvalue}`;
    var x = document.getElementById("submitcontinuartres");
    if (x.style.display === "block") {
        x.style.display = "none";
    } else {
        x.style.display = "block";
    }
    
};
 
const segunnum = () =>{
    segform.classList.toggle("show");
    confprimnum.classList.toggle("show");
    var y = document.getElementById("confsegnum");
    if (y.style.display === "block") {
        y.style.display = "none";
    } else {
        y.style.display = "block";
    }
    var z = document.getElementById("buttonsdiv");
    if (z.style.display === "block") {
        z.style.display = "none";
    } else {
        z.style.display = "block";
    }
    const segunnumvalue = document.getElementById("segnum").value;
    const confsegunnum = document.getElementById("confsegnum").innerHTML = `Tu segundo número es ${segunnumvalue}`;
    const name = document.getElementById("nombre").value;
    const textosgdo = document.getElementById("textobuttons").innerHTML = ` ${name} Tus números son el 10 y el 30. <br> Adivina el número dentro de ese rango que ha pensado la máquina aleatorimente.`
    randomnum();
};


function getRandomIntInclusive(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min); // The maximum is inclusive and the minimum is inclusive
  }
const randomnum = () => {
const primnumvalue = parseInt(document.getElementById("primnum").value);
const segunnumvalue = parseInt(document.getElementById("segnum").value);
console.log(primnumvalue);
console.log(segunnumvalue);
let n = getRandomIntInclusive(primnumvalue, segunnumvalue);
console.log(n);

const randomnumaquina = function() {
let botoncorrecto;
  botoncorrecto = botoncorrecto ? botoncorrecto :n;
  for(cont = 0; botoncorrecto == this.id;){
    document.getElementById("confintento").innerHTML= `<span style='color: green;'>FELICIDADES!<br> Acertaste el número.</span>`;
    congrats();
    return true;
    
  }if(botoncorrecto > this.id){
    cont++;
    document.getElementById("confintento").innerHTML=`Número (${this.id}) erróneo y menor que el generado por la máquina.INTENTOS: ${cont}`;
    
  } else if(botoncorrecto < this.id){
    document.getElementById("confintento").innerHTML=`Número (${this.id}) erróneo y mayor que el generado por la máquina. INTENTOS: ${cont}.`;
    cont++;
    
  }else if(cont=5){
    congrats();
  }
  
}
for (let i = primnumvalue; i <= segunnumvalue; i++) {
  const buton = document.createElement("button")
  document.getElementById("buttonsdiv").appendChild(buton)
  buton.id = i
  buton.innerText = i;
  buton.addEventListener("click", randomnumaquina);
}
};
const congrats = () =>{
    var h = document.getElementById("reiniciar");
    if (h.style.display === "block") {
        h.style.display = "none";
    } else {
        h.style.display = "block";
    }
    var b = document.getElementById("salir");
    if (b.style.display === "block") {
        b.style.display = "none";
    } else {
        b.style.display = "block";
    }
};
const reiniciarfunct = () => {
    location.reload();
};
const salirfunct = () => {
    window.location.href="http://www.w3schools.com";
};
submitcontinuaruno.addEventListener("click", segundaparte);
submitcontinuardos.addEventListener("click", nums);
submitcontinuartres.addEventListener("click", segunnum);
reiniciar.addEventListener("click", reiniciarfunct);
salir.addEventListener("click", salirfunct);


