<?php

function sanitize($data){
    trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
  }
function vista_registro_completado($usuario,$email, $rows, $lang_form){
	$div = "<div>";
	if(!empty($rows)){
		foreach($rows as $value){
			$div = "<p>(".$value["id"].")-".$value['usuario'].":".$value['email']."</p>";
		}
		$div = "</div>";
	}

	$params=[
		"usuario"=>$usuario,
		"email"=>$email,
		"div"=> $div

	];
	$params = array_merge($params, $lang_form);
	mostrar_tpls($params,"../view/tpls/feedback.tpl");

}

function vista_registro_incorrecto($usuario,$email, $lang_form){
	_vista_form_registro($usuario, $email, false, $lang_form);

}

function vista_mostrar_formulario_registro($lang_form){
	 _vista_form_registro("", "", true,$lang_form);
	 
}



	function _vista_form_registro($usuario,$email,$primera_vez, $lang_form){
	$mensaje_error="";
	$class_error="";
	
	if(!$primera_vez){
		$class_error="error";
		$mensaje_error="Usuario o correo ya registrado. Corrígelos i vuelve a intentarlo";
	}
	
	$params=[
		"usuario"=>$usuario,
		"email"=>$email,
		"class_error"=> $class_error,
		"mensaje_error"=> $mensaje_error,
	];
	$params = array_merge($params, $lang_form);
	mostrar_tpls($params,"../view/tpls/form.tpl");
}

function mostrar_tpls($params,$archivo){
	
	$html= file_get_contents($archivo);
	foreach ($params as $key => $value) {
		$html=str_replace("{{::$key::}}",$value,$html);
	}
	//var_dump($html);
	
	echo $html;
	exit;
}

/* function _vista_form_registro($usuario,$email,$primera_vez){
	?>
	<!DOCTYPE html>
	<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Users fichero</title>
		<style type="text/css">
			.error{border:2px solid red;}
		</style>

	</head>
	<body>
		<form method="post" action="../controller/app.php">
			Usuario: <br><input type="text" class="<?php echo !$primera_vez? 'error': '' ?>" name="usuario" value="<?php echo $usuario; ?>" /><br><br>
			Email: <br><input type="text" class="<?php echo !$primera_vez? 'error': '' ?>" name="email" value="<?php echo $email; ?>" /><br><br>
			<input type="submit" name="registrar" value="Registrar" /><br>

			<?php 
			if(!$primera_vez){

				echo "El formulario contiene errores. Corrígelos y vuelve a intentarlo.";
			}
			?>
		</form>
		
	</body>
	</html>
	<?php

} */
?>   