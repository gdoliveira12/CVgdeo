<?php

/*require_once "controller/app.php";*/
header("Location:controller/app.php");
?>