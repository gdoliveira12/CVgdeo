<?php
session_start();
require "../model/model.php";
require_once "../lang/idiomas.php";
require "../view/view.php";

/* require "../libreria.php"; */

/* if(isset($_GET['lang'])){
	if("es" ==$_GET['lang']){
		  $_SESSION['idioma']="es";
	}elseif("cat" == $_GET['lang']){
		  $_SESSION['idioma']="cat";
	}

}elseif(!isset($_SESSION['idioma'])){
	$_SESSION['idioma']="es";
}
require $_SESSION['idioma'].".php";


function sanitize($data){
    trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
  }
 */
 
 
function action_nuevo_usuario($con, $lang_form){
if(($_SERVER["REQUEST_METHOD"]==="POST") && isset($_REQUEST['registrar']))
{

	$usuario =isset($_REQUEST['usuario'])? $_REQUEST['usuario'] :"";
	$email =isset($_REQUEST['email'])? $_REQUEST['email'] :"";
	
	$usuario=sanitize($usuario);
	$email = sanitize($email);

	//validar datos
	list($rows,$ok)=modelo_registrar_nuevo_usuario($usuario,$email,$con);
		if($ok){
			//Nos devuelve el modelo un true
			vista_registro_completado($usuario,$email,$rows,$lang_form);
				exit;
			}else{
			vista_registro_incorrecto($usuario,$email,$lang_form);
				exit;
			}
		}
}
//si no existe un action eclarado
if(!isset($_REQUEST['registrar'])){
	vista_mostrar_formulario_registro($lang_form);
}else{
	action_nuevo_usuario($con, $lang_form);
}

/* if(!isset($_REQUEST['action']))
			vista_mostrar_formulario_registro();



            
	$action="action_".$_REQUEST["action"];

	$ejecuta=call_user_func($action);

 */
/* if(!$ejecuta)
	vista_mostrar_formulario_registro(); */


?>