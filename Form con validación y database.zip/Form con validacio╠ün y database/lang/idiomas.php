<?php


// require_once "./12_usersfitxer_ok_2/model/connect.php"; 
if(isset($_GET['lang'])){
      if("es" ==$_GET['lang']){
            $_SESSION['idioma']="es";
      }elseif("cat" == $_GET['lang']){
            $_SESSION['idioma']="cat";
      }

}elseif(!isset($_SESSION['idioma'])){
      $_SESSION['idioma']="es";
}
require $_SESSION['idioma'].".php";
/* function form ($lang){
      ?>	
          <!DOCTYPE html>
          <html lang="es">
          <head>
              <meta charset="UTF-8">
              <title>Users fichero</title>
              <style type="text/css">
                  .error{border:2px solid red;}
              </style>
      
          </head>
          <body>
              <p><a href="?lang=es">es</a> || <a href="?lang=cat">ca</a></p>
              <form method="post" action="../controller/app.php">
          
                  <h1> <?= $lang['form_reg']; ?> </h1>
                  <label > <?= $lang['user']; ?> </label><br><input type="text" class="{{::class_error::}}" name="usuario" value="{{::usuario::}}" /><br><br>
                  <label for="Email:"> <?= $lang['email']; ?> </label><br><input type="text" class="{{::class_error::}}" name="email" value="{{::email::}}" /><br><br>
                  <input type="hidden" name="action" value="nuevo_usuario">
                  <input type="submit" name="registrar" value=" <?= $lang['terminar']; ?>" /><br>
                  {{::mensaje_error::}}
                  
              </form>
              
          </body>
          </html>
          <?php
      } */
?>