<?php
$lang_form = [
    "form_reg" => "Formulario de registro",
    "user" => "Usuario",
    "emaill" => "Correo electrónico",
    "terminar"=>"Finalizar",
    
];


?>