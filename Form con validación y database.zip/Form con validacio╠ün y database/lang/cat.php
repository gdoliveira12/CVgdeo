<?php
$lang_form = [
    "form_reg" => "Formulari de registre",
    "user" => "Usuari",
    "emaill" => "Correu electrònic",
    "terminar"=>"Finalitzar",
    
];


?>