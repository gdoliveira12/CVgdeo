<?php
 
require "../model/connect.php";

function modelo_registrar_nuevo_usuario($usuario,$email, $con){
	//lectura.....intenta escribir
	if (empty($usuario)||empty($email)) return false;

	/* $salida=""; */
	$myrows = [];
	$selectQuery = "SELECT*FROM usuarios WHERE usuario='$usuario' OR email='$email'";
	$result = $con->query($selectQuery);
	if($result->num_rows >0){
		return false;
	}
	$insertQuery= "INSERT INTO usuarios VALUES (NULL,'$usuario','$email')";
	$result = $con->query($insertQuery);

	if($result){
		$selectallQuery="SELECT*FROM usuarios";
		$result = $con->query($selectallQuery);
		while($row = $result->fetch_assoc()){
			$myrows[] = $row;
		}

		$con ->close();
		return [$myrows, true];

	}else {
		return false;
	}
	


	
	/* $usuarios= fopen("../model/usuarios.txt","a+");
	
	$usuarios= file("../model/usuarios.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

	foreach ($usuarios as $linea) {
		list($user,$em)=explode(" - ",$linea);
		
		if($usuario===$user) return false;
		if($email===$em) return false;


  $salida.=$linea."\n"; 
        
	}

	$salida.="$usuario - $email";

	file_put_contents("../model/usuarios.txt", $salida);

	

	return true; */
		

}



?>